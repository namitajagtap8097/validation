import { Component, OnInit } from '@angular/core';
import { ValidationService } from '../validation.service';
import { NgForm } from '@angular/forms';


@Component({
  selector: 'app-validation',
  templateUrl: './validation.component.html',
  styleUrls: ['./validation.component.css']
})
export class ValidationComponent implements OnInit {
  validation: any = {};
  Validation: Array<any>;
  constructor(private Service: ValidationService) { }

  ngOnInit() {

    this.Service.getAll().subscribe(data => {
      this.Validation = data;
    });
  }

    save(form: NgForm) {
      this.Service.save(form).subscribe(result => {
      });
  }

}


