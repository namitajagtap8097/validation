export class Validation{
  
    email:string;
    mobileno:string;
   

}

