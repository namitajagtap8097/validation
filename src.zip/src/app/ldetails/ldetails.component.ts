import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ldetails',
  templateUrl: './ldetails.component.html',
  styleUrls: ['./ldetails.component.css']
})
export class LdetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
