import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { Validation } from './validation/validation';
import { ValidationComponent } from './validation/validation.component';


const routes: Routes = [
    {path:"validation",component:ValidationComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }


