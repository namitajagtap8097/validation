import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/internal/Observable';
import { Validation } from './validation/validation';


@Injectable({
  providedIn: 'root'
})
export class ValidationService {

  constructor(private http: HttpClient) { 

  }
  getAll(): Observable<any> {
    return this.http.get('http://localhost:8080/');
  }


  save(Validation: any): Observable<any> {
    let result: Observable<Object>;
      result = this.http.post('http://localhost:8080/validation_add/', Validation);
    return result;
  }

}


