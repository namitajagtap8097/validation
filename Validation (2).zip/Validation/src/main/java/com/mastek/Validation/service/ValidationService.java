package com.mastek.Validation.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mastek.Validation.model.Validation;

@Service
public class ValidationService {
	@Autowired(required=true)
	com.mastek.Validation.repository.IValidationRepository IValidationRepository;
	 public	Iterable<Validation> findAll()
		{
			return IValidationRepository.findAll();
			
		}
		
	 public String save(Validation entity) {
		 Validation newVal =IValidationRepository.save(entity);
			return "Added " +newVal;
		}


	

}



