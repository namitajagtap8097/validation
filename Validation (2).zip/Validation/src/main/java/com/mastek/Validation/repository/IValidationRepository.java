package com.mastek.Validation.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.mastek.Validation.model.Validation;

@Repository
public interface IValidationRepository extends CrudRepository<Validation, Integer> {
	

}
