package com.mastek.Validation.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mastek.Validation.model.Validation;

@RestController
@CrossOrigin("http://localhost:4200/")
public class ValidationController {
	
	@Autowired(required = true)
	com.mastek.Validation.service.ValidationService ValidationService; 
	
	
	 @GetMapping(path="/" ,produces="application/json")
		public Iterable<Validation> findAll(){
			return ValidationService.findAll();
			
		}
	      
	    	
	@PostMapping(path="/validation_add",produces="application/json")
		public String save(@RequestBody Validation email) {
			return ValidationService.save(email);
		}


}


//package com.mastek.registration.controller;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.web.bind.annotation.CrossOrigin;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RestController;
//
//import com.mastek.registration.model.UserRegistration;
//import com.mastek.registration.service.UserRegistrationService;
//
//
//@RestController
//@CrossOrigin("http://localhost:4200/")
//
//
//public class UserRegistrationController {
// @Autowired(required = true)
//UserRegistrationService userRegistrationService;
// 
// 
//      @GetMapping(path="/" ,produces="application/json")
//	public Iterable<UserRegistration> findAll(){
//		return userRegistrationService.findAll();
//		
//	}
//      
//    	
//@PostMapping(path="/userdetails_add",produces="application/json")
//	public String save(@RequestBody UserRegistration customer) {
//		return userRegistrationService.save(customer);
//	}
//
//
//	

